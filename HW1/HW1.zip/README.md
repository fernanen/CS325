Instrictions to run python code. 
 - Make sure you have the data.txt file in the same directory you are running the python files.
 - run insertsort.py using python 2.7.5 (default intepreter in access.engr.oregonstate.edu).
 - run mergesort.py using python 2.7.5.
